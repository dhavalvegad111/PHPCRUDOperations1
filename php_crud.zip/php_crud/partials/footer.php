    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <!-- bootstrap bundle js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <!-- dataTables js -->
    <script src="https://cdn.datatables.net/2.0.0/js/dataTables.js"></script>
    <!-- dataTables bootstrap js -->
    <script src="https://cdn.datatables.net/2.0.0/js/dataTables.bootstrap5.js"></script>
    <!-- custom -->
    <script src="./assets/js/script.js"></script>
    <script>

    </script>
    </body>
</html>


