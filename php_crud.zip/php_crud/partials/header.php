<?php include('conn.php'); 
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- utilities -->
    <link rel="stylesheet" href="./assets/css/utilities.css">
    <!-- bootstrap css 5.3 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <!-- dataTables bootstrap css -->
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.0/css/dataTables.bootstrap5.css">
    <!-- custom -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <title>PHP CRUD Operations</title>
    <style>

    </style>
</head>
<body class="bg:slate-100">
<h1 class="text:center pt:50">PHP CRUD OPERATIONS</h1>
<hr>    