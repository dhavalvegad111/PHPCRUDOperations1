<?php include('./partials/header.php'); 

if(isset($_GET['id'])){
    $id = $_GET['id'];
}

$result = mysqli_query($conn,"SELECT * FROM persons WHERE id = '$id'");
if (!$result) {
    $_SESSION['msg']= 'Could not run query: ' . mysqli_error($conn);
    exit;
}
$row = mysqli_fetch_assoc($result);
    ?>

<section class="read_single_record">
    <div class="container">       
    <div class="py:20">
        <a href="index.php" class="createBtn text-decoration:none weight:bold text:uppercase text:white bg:blue-600 py:10 px:20">Back</a>
    </div> 
    <div class="table_wrapper display:flex justify-content:center py:40">
    <table class="ww:100" border="1" id="read_table">
        <thead>
            <tr class="bg:slate-300">
                <th class="p:15 text:uppercase">ID</th>
                <th class="p:15 text:uppercase">Firstname</th>
                <th class="p:15 text:uppercase">Lastname</th>
                <th class="p:15 text:uppercase">Gender</th>
                <th class="p:15 text:uppercase">Address</th>
                <th class="p:15 text:uppercase">Hobbies</th>
                <th class="p:15 text:uppercase">Updated On</th>
            </tr>
        </thead>
        <tbody class="table-group-divider">
            <tr class="">
                <td class="p:15"><?php echo $row['id']; ?></td>
                <td class="p:15"><?php echo $row['fname']; ?></td>
                <td class="p:15"><?php echo $row['lname']; ?></td>
                <td class="p:15"><?php echo $row['gender']; ?></td>
                <td class="p:15"><?php echo $row['address']; ?></td>
                <td class="p:15"><?php echo $row['hobbies']; ?></td>
                <td class="p:15"><?php echo $row['date']; ?></td>
            </tr>        
        </tbody>
    </table>
    </div>        
    </div> 
</section>

<?php include('./partials/footer.php'); ?>