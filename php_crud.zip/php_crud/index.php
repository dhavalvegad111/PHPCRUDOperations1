<?php include('./partials/header.php'); ?>

<section class="view_table">
    <div class="container">               
        <div class="py:20">
            <a href="insert.php" class="createBtn text-decoration:none weight:bold text:uppercase text:white bg:blue-600 py:10 px:20">Create</a>
        </div> 
        <div class="table_wrapper ww:100">         
            <?php
                if (isset($_SESSION['msg'])) {
                    echo "<p class='msg bg:stone-800 text:white weight:semibold p:15 size:18 mb:20'>" . $_SESSION['msg'] . "</p>";
                    unset($_SESSION['msg']);
                }
            ?>
            <table id="crud_table" class="table table-striped table-bordered border-gray table-hover">
                <thead class="">
                    <tr class="vertical:middle">
                        <th class="text:center text:uppercase">ID</th>
                        <th class="text:center text:uppercase">Firstname</th>
                        <th class="text:center text:uppercase">Lastname</th>
                        <th class="text:center text:uppercase">Gender</th>
                        <th class="text:center text:uppercase">Address</th>
                        <th class="text:center text:uppercase">Hobbies</th> 
                        <th class="text:center text:uppercase">Updated On</th> 
                        <th class="text:center text:uppercase">Actions</th>
                    </tr>
                </thead>
                <tbody>  
                    <?php
                    $query = "SELECT * FROM persons";
                    if ($result = mysqli_query($conn, $query)) {
                        while ($row = mysqli_fetch_assoc($result)) {  

                    ?>
                    <tr class="vertical:middle">
                        <td class=""><?php echo $row['id']; ?></td>
                        <td class=""><?php echo $row['fname']; ?></td>
                        <td class=""><?php echo $row['lname']; ?></td>
                        <td class=""><?php echo $row['gender']; ?></td>
                        <td class=""><?php echo $row['address']; ?></td>
                        <td class=""><?php echo $row['hobbies']; ?></td>
                        <td class=""><?php echo $row['date']; ?></td>
                        <td class="display:flex gap:20">
                            <a href="read.php?id=<?php echo $row['id']; ?>" class="readBtn text-decoration:none weight:bold text:uppercase text:white bg:slate-600 py:10 px:20">Read</a>
                            <a href="update.php?id=<?php echo $row['id']; ?>" class="updateBtn text-decoration:none weight:bold text:uppercase text:white bg:green-600 py:10 px:20">Update</a>
                            <form action="delete.php" method="post"><input type="hidden" name="id" value="<?php echo $row['id']; ?>"><input type="submit" value="Delete" class="deleteBtn text-decoration:none weight:bold text:uppercase text:white bg:red-600 py:10 px:20 border:none"></form>
                        </td>
                        
                    </tr>
                    <?php } } ?>
                </tbody>               
            </table>    
        </div>
    </div> 
</section>

<?php include('./partials/footer.php'); ?>