<?php include('./partials/header.php');

// UPDATE QUERY
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $hobbies = implode(", ", $_POST['hobbies']);

    $update_query = mysqli_query($conn, "UPDATE persons SET fname='$fname', lname='$lname', fname='$fname', gender='$gender', address='$address', hobbies='$hobbies' WHERE id='$id'");

    if ($update_query > 0) {
        header("Location:index.php");
        $_SESSION['msg'] = "Record updated successfully.";
    } else {
        $_SESSION['msg'] = "Error in update record.";
    }
}

// SELECT QUERY
$id = $_GET['id'];
$select_query = mysqli_query($conn, "SELECT * from persons WHERE id = $id");
while ($row = mysqli_fetch_array($select_query)) {
?>
<div class="container">
    <div class="form_wrapper">
        <form action="update.php" method="POST">
            <div class="display:flex gap:10">
                <input type="text" name="fname" placeholder="Firstname" autocomplete="off" value="<?php echo $row['fname']; ?>"><br>
                <input type="text" name="lname" placeholder="Lastname" autocomplete="off" value="<?php echo $row['lname']; ?>"><br>
            </div>

            Gender:
            <input type="radio" id="male" name="gender" value="Male" <?php if ($row['gender'] == 'Male') {echo "checked";} ?>>
            <label for="male">Male</label>
            <input type="radio" id="female" name="gender" value="Female" <?php if ($row['gender'] == 'Female') {echo "checked";} ?>>
            <label for="female">Female</label><br>
            
            <textarea name="address" id="address" cols="30" rows="10" placeholder="Address" class="outline:none" value=""><?php echo $row['address']; ?></textarea><br>

            Hobbies:<br>
            <?php
            $save_hobbies = explode(", ", $row['hobbies']);
            $hobbies = array("Drawing", "Dancing", "Reading", "Watching TV", "Swimming", "Cooking");
            foreach ($hobbies as $hobby) {
                $checked = in_array($hobby, $save_hobbies) ? "checked" : "";
            ?>
                <input type="checkbox" name="hobbies[]" id="" value="<?php echo $hobby ?>" <?php echo $checked ?> class="mr:5">
                <label for="hobbies1" class="mr:10 text:uppercase"><?php echo $hobby ?></label>
            <?php
            }
            ?><br><br>

            <input type="hidden" name="id" value=<?php echo $_GET['id']; ?>>
            <input type="submit" value="Update" name="update" class="py:5 px:15">
        </form>
<?php } ?>
    </div>
</div>

<?php include('./partials/footer.php'); ?>