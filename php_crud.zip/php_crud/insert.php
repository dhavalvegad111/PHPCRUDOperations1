<?php include('./partials/header.php'); 

if (isset($_POST['submit'])) {

  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $gender = $_POST['gender'];
  $address = $_POST['address'];
  $hobbies = implode(", ", $_POST['hobbies']);  
  
  if (!empty($fname) && !empty($lname) && !empty($gender) && !empty($address) && !empty($hobbies)) {
    
    $query = "INSERT INTO `persons`(`fname`, `lname`, `gender`, `address`, `hobbies`) VALUES ('$fname','$lname','$gender','$address','$hobbies')";
    $result = mysqli_query($conn, $query);

    if ($result) {
      header("Location:index.php");
      $_SESSION['msg']="Record created successfully.";
    } else {
      echo "Failed to create a record." . mysqli_error($conn);
    }
    
  } else {
    echo "Please fill out all fields.";
  }
}
?>

<div class="container">
  <div class="form_wrapper">
    <form action="insert.php" method="POST">
      <div class="display:flex gap:10">
        <input type="text" name="fname" placeholder="Firstname" autocomplete="off"><br>
        <input type="text" name="lname" placeholder="Lastname" autocomplete="off"><br>
      </div>
      
      Gender:
      <input type="radio" id="male" name="gender" value="Male">
      <label for="male">Male</label>
      <input type="radio" id="female" name="gender" value="Female">
      <label for="female">Female</label><br>
      <textarea name="address" id="address" cols="30" rows="10" placeholder="Address" class="outline:none"></textarea><br>
   
      Hobbies:<br>
      <?php
        $hobbies = array("Drawing","Dancing","Reading","Watching TV","Swimming","Cooking");
        foreach($hobbies as $hobby){
      ?>
        <input type="checkbox" name="hobbies[]" id="" value="<?php echo $hobby ?>" class="mr:5">
        <label for="hobbies1" class="mr:10 text:uppercase"><?php echo $hobby ?></label>
      <?php        
        }
      ?>

      <input type="submit" value="Save" name="submit" class="py:5 px:15">
    </form>
  </div>
</div>

<?php include('./partials/footer.php'); ?>
